title: 看源码，我为什么推荐IDEA?
date: '2019-06-01 13:39:27'
updated: '2019-06-01 13:41:54'
tags: [转载]
permalink: /articles/2019/06/01/1559367567644.html
---
>文章转载自微信公众号 肥朝 文章  [看源码，我为什么推荐IDEA?]([https://mp.weixin.qq.com/s?__biz=MzA4NjgxMjQ5Mg==&mid=2665761638&idx=1&sn=51d5cb7fa16e51a2cdec4fb5a073781b&chksm=84d21945b3a59053ebb86bc220cdf5def37a0d407dde4f16b46038809294381feec45c9aff67&scene=27#wechat_redirect](https://mp.weixin.qq.com/s?__biz=MzA4NjgxMjQ5Mg==&mid=2665761638&idx=1&sn=51d5cb7fa16e51a2cdec4fb5a073781b&chksm=84d21945b3a59053ebb86bc220cdf5def37a0d407dde4f16b46038809294381feec45c9aff67&scene=27#wechat_redirect))，侵权立删

---

> 本文并不评论Eclipse与IDEA孰好孰坏,但是由于肥朝平时都是使用IDEA开发的,所以推荐IDEA.这个和肥朝平时都是吃粤菜,所以推荐的都是粤菜为主,但是并不是说其他菜不好吃,肥朝不挑食!

1.条件断点
------

看源码的时候,经常遇到这个情况,源码中有个for循环,关键是这个list的size有时候长达数百个.但是我们只想debug一种情况.肥朝就曾经见过,在for循环中打了断点,一直按跳过,按了数十下之后.才找到自己想debug的值.这样效率不高

比如下文这个

```java
@Test  
public void testList() throws Exception {  
    List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);  
    for (Integer integer : list) {  
        System.out.println(integer);  
    }  
}  

```

如果你想debug数字10这种情况,如果你不知道条件断点,那么你可能要一直点9次跳过.我们来看一下条件断点的使用

![image.png](https://img.hacpai.com/file/2019/06/image-26421684.png)

 这样,就只有满足条件的时候才会进入断点了,告别无效的`小手一抖`!

2.强制返回值
-------

比如SpringBoot中这个打印Banner的.我们想调试多种情况.就可以利用这个`Force Return`,这样方便我们调试源码中的多种分支流程

![image.png](https://img.hacpai.com/file/2019/06/image-2cad1931.png)

3.模拟异常
------

在做业务开发中,我们有时需要模拟某个方法抛出异常,看看自己的代码是不是像肥朝一样可靠得一逼.但是你每次去写死一个异常,然后再删掉,这种低效的方式有违极客精神.那么我们如果让一个方法抛出异常呢?

![image.png](https://img.hacpai.com/file/2019/06/image-2c0d9d28.png)

不过要注意的一点是,这个功能印象中是IDEA 2018年以后的版本才有的功能.

4.Evaluate Expression
---------------------

比如我们看源码时遇到这个一个场景,这里有一个`byte[]`,但是我们就想看一下这个的值到底是啥.

![image.png](https://img.hacpai.com/file/2019/06/image-863a7058.png)

那么我们可以这么操作一波

![image.png](https://img.hacpai.com/file/2019/06/image-57590b8e.png)

这个功能的使用场景非常的广,通过这个功能,可以在看源码时,给某个变量赋我们要想的值,从而改变代码的分支走向等等.总之,这个是肥朝看源码中,使用频率最高的功能之一.更多场景,等待`老司机们自己调教!`

5.toString的坑(重点)
----------------

相信看过Dubbo源码的朋友都会遇到过这个一个坑.也就是你把断点打在下面图示的第一个箭头的时候,是无法进入`init()`方法的.但是你把断点打在第二个箭头也就是`init()`方法的时候,是能进入的.曾经也有不少人问过这个问题.

![image.png](https://img.hacpai.com/file/2019/06/image-f47f7141.png)

![image.png](https://img.hacpai.com/file/2019/06/image-0c639093.png)
  

当然除了这个坑之外,也有类似的坑,如下

![image.png](https://img.hacpai.com/file/2019/06/image-9517aa35.png)
所以这个idea的默认设置.建议在一定条件下还是关闭。

![image.png](https://img.hacpai.com/file/2019/06/image-e4ace733.png)
