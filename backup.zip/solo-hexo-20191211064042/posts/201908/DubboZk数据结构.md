title: Dubbo Zk 数据结构
date: '2019-08-11 17:12:31'
updated: '2019-08-19 16:02:58'
tags: [dubbo, ZooKeeper]
permalink: /articles/2019/08/11/1565514751471.html
---
# 注册中心工作流程

dubbo 注册中心工作流程如图所示。

![image.png](https://img.hacpai.com/file/2019/08/image-fdc936cd.png)

服务提供者启动时会将服务信息写入注册中心。服务消费者启动时，也会将消费者信息写入注册中心，以及订阅提供者信息。

当服务提供者服务增加或者下线时，注册中心服务提供者发生变化，将会主动通知消费者。

## ZooKeeper 注册中心

上次分享提到过，ZooKeeper 存在多种类型的节点，而 dubbo 创建的节点为持久节点以及临时节点。

一个 `com.service.FooService` 在 ZooKeeper 中路径为 `/dubbo/com.service.FooService/providers/providerURL`。

服务路径主要分为四层，根节点默认为 dubbo。可以在 dubbo-registry 设置 group 属性改变该值。

第二个节点为服务节点全名称，如  `com.service.FooService`。

第三个节点为服务目录，如 providers。另外还存在其他目录节点，分别为 consumers（消费者目录），configurators（配置目录），routers（路由目录）。

第四个节点为具体服务节点，节点名为具体的 URL 字符串，如 `dubbo://2.0.1.13:12345/com.dubbo.example.DemoService?xx=xx` ，该节点类型为临时节点。

树形结构示例为：

![image.png](https://img.hacpai.com/file/2019/08/image-5ae692eb.png)

一个服务在 ZooKeeper 具体示例如下：

 ![Snipaste20190811170204.png](https://img.hacpai.com/file/2019/08/Snipaste20190811170204-8ccbf03e.png)

