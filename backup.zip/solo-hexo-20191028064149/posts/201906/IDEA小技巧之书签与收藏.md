title: IDEA 小技巧之书签与收藏
date: '2019-06-09 15:40:48'
updated: '2019-06-09 20:06:28'
tags: [tips]
permalink: /bookmark_and_favorites
---
![](https://img.hacpai.com/bing/20180615.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近翻阅 **Spring** 源码，由于源码调用链路很长，等看了十几类方法之后，想看前面调用方法就很不方便，需要查找历史的查看记录。还有时候看着看着就忘了中间某个方法，于是又要重新重头开始 :collision: 。

下面介绍 IDEA 两个功能，可以有效解决上述烦恼。

## 书签

首先介绍的是 IDEA 的书签功能，可以通过书签快速跳转到相应的源码。

IDEA 书签分为两种，

* 匿名书签，可以生成无数个，使用快捷键 `F11` 快速生成。
* 标记书签，可以用数字或字母标记书签，总共只能生成 10 个数字以及 26 个字母的标记书签，使用快捷键 `Ctrl+F11`生成。

两种标签区别如下。

![image.png](https://img.hacpai.com/file/2019/06/image-9a6d8c47.png)

使用快捷键 `Shift + F11`，可以打开书签管理窗口，在这里可以删除标签，排序标签，以及给标签添加简单的解释。

![image.png](https://cdn.nlark.com/yuque/0/2019/png/254022/1560065412297-43123ab9-d92c-4fe3-a487-279d941986c4.png)

另外使用数字标记的标签，可以使用 `Ctrl + 数字键`  跳转到相应标签，快速查看源码。

![numbookmark.gif](https://img.hacpai.com/file/2019/06/numbookmark-12e4ac84.gif)

## 收藏夹

第二个介绍的是收藏夹功能，在 IDEA 中，这个功能位于 **Favorites**。

这个功能可以将文件，文件夹，甚至外部文件加入到 **IDEA  Favorites**。

> 上面说的标签以及断点会自动加入到 **Favorites**中。

使用 `Alt + 2` 可以快速打开 **Favorites** 列表。

![image.png](https://cdn.nlark.com/yuque/0/2019/png/254022/1560065466895-74f92014-7e56-47cb-aa6e-24384af92def.png)