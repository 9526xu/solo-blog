title: 解决 IDEA 无法找到 java.util.Date 的问题
date: '2019-06-01 17:43:56'
updated: '2019-06-01 17:45:03'
tags: [tips]
permalink: /articles/2019/06/01/1559382236231.html
---
## 问题

最近在项目中频繁使用到 **java.util.Date**，但是使用 IDEA 提示查找 Date 类，却无法找到 **java.util.Date**。

![image.png](https://img.hacpai.com/file/2019/06/image-ca898afe.png)

可以看到，智能提示的结果没有 **java.util.Date**。没办法，只能暂时手动导入该包。

最近闲下来，又碰到该问题，查找了一番解决过程，终于将其解决。

首先我们打开 **File|Setting|Editor|Auto Import**。

![image.png](https://img.hacpai.com/file/2019/06/image-a1ea9990.png)

可以看到这里显示排除了 **java.util.Date**，这就是根本原因😰 。将其删除，保存改配置。

![image.png](https://img.hacpai.com/file/2019/06/image-2d3c73f6.png)

可以看到 现在终于可以显示了。

>ps: 个人猜测 IDEA 默认排除 **java.util.Date** 目的是为了让人们使用 Java8 新时间 API。。

## 总结

如果一些类，无法使用 IDEA 中提示找到的话，如果已经排除包未引入的问题，可以查找该设置，是否有设置。

另外，有些情况下，工程中存在多个同名类，而我们只想使用某一个的话，可以在其他都在设置中排除，眼不见心不烦，哈哈。

