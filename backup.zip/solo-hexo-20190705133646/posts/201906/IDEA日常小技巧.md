title: IDEA 日常小技巧
date: '2019-06-02 16:54:06'
updated: '2019-06-02 17:09:46'
tags: [tips]
permalink: /articles/2019/06/02/1559465646386.html
---
![](https://img.hacpai.com/bing/20180623.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 原文首发于 [studyidea.cn点击查看更多技巧](https://studyidea.cn/) ,转载请保留原文地址。

---     
> 适用于 IDEA 2019.2 之前版本 ，2019.2 版本以下功能默认开启。   

## Surround a selection with a quote or brace

默认情况下，选中文本的再输入其他，选中文本将会被输入的字符代替。

如果我们想输入双引号引用选中字符，选中字符将会被替换成双引号，非常尴尬 😰 。这种情况下，不得不先输入双引号，然后将选中字符剪贴到双引号中。

![selected.gif](https://img.hacpai.com/file/2019/06/selected-9a9bf0a5.gif)

在 IDEA 中，有个选项可以改进。**Setting|Smart keys** 选中 **Surround a selection with a quote or brace**。

![image.png](https://img.hacpai.com/file/2019/06/image-6a73c4d7.png)

默认情况下，该选择没有选中。选中保存之后，选中文本输入引号或括号等，不在被替代，选中文本将会被引号包围。

![selectedsurround.gif](https://img.hacpai.com/file/2019/06/selectedsurround-44d506f4.gif)

## Jump outside the closing bracket or quote with Tab

该选项可以在输入完引号或括号之后，使用 **Tab** 快速跳出到外面。

这个选项也在 **Setting|Smart keys** 打开。该选项默认没有选中，默认情况下，输完引号，再使用 tab 将会键入 Tab 字符。

![image.png](https://img.hacpai.com/file/2019/06/image-0fbb939d.png)

选中之后，效果如下：

![tabjumpout.gif](https://img.hacpai.com/file/2019/06/tabjumpout-7f887d95.gif)









