title: 为什么将 Intellij IDEA 作为日常开发的首选
date: '2019-05-30 21:26:36'
updated: '2019-10-16 13:01:03'
tags: [IDEA]
permalink: /-why_choose_idea
---
![](https://img.hacpai.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

作为一个从事 Java 开发的程序员，每天离不开编辑器的帮助。还记得刚开始学习 Java 编程的时候，使用 Eclipse 作为日常开发工具。后来工作以后，需要使用 Intellij IDEA，刚开始其实并不想怎么用。毕竟 Eclipse 已经足够强大，可以满足日常开发的需求，何必再花时间再去学习其他工具那。刚开始改变是困难的。但是没办法，公司强制使用，不得不去了解去使用。后来用了一段时间才发现 IDEA 是的真的强大。

真香啊~

下面就来介绍一下本人觉得 IDEA 一些强大的功能。

> 文中提到的快捷键只适用于 Windows 平台

## 更加智能的协助开发

我们使用编辑器的目的就是在于简化开发难度，加快开发速度。IDEA 就有许多功能，可以更加智能的、更加快速的帮你完成代码开发。

### 代码提示

下面先介绍最基本的代码提示功能。

一般编辑器都会提供基本提示功能，可以快速提供可用的方法，变量等。当然 IDEA 也存在这个，在 IDEA 中使用  `Ctrl + Space` 可以快速提示。

----
PS：对于 Windows 平台用户，这个快捷键十分不友好，与输入法切换快捷键冲突，可以使用如下方法解决。

> 1、 打开注册表，跳转到HKEY_CURRENT_USER/Control Panel/Input Method/Hot Keys目录下面  
>2.、选择00000070（中文繁体）或者00000010（中文简体）  
>3.、将Key Modifiers的第一个字节设置为00（02c00000->00c00000）  
>4、 将Virtual Key的第一个字节设置为ff（20000000->ff000000）  
>5、 注销用户然后重新登录，搞定。  
>另外 HKEY_CURRENT_USER/Control Panel/Input Method/Hot Keys，保存的是当前用户的快捷键配置；
>HKEY_USERS.DEFAULT\Control Panel\Input Method\Hot Keys，保存的是默认的快捷键配置；
>若修改上一个注册表不好使，那就把下面的默认的也修改了。  
**经测试，修改第一个，重启之后不再生效，所以默认配置也需要修改**。
----
除了最基本的代码提示功能，IDEA 还提供更加智能的代码提示功能，该功能可以基于上下文环境，智能帮你过滤可以使用方法，推导出最适合的方法。该快捷键为 `Ctrl+Shift+Space`。

我们用下面两张图比对两者的区别。

基本提示功能：

![基本提示](https://i.postimg.cc/wvbpzdJ9/image.png)

智能代码提示：

![智能代码提示](https://i.postimg.cc/K8yyxfK3/image.png)

观察上面两图可以看出，基本代码提示功能会显示所有可用的方法建议，而智能代码提示根据上下文过滤了其他不可用的提示。

### 参数提示

当一个方法参数列表过多时，我们往往只会记住前两个参数类型，而后面参数类型我们只能去翻阅方法才。在 IDEA 中，你无需这般做。只要你将光标放置在放入参数列表中，暂停一会，IDEA 就会帮你智能提示。

如果并不想等待一会，也可以，在方法内使用 `ctrl +P` 也可以快速出现提示框。

![方法提示](https://i.postimg.cc/RhnjzJ4T/image.gif)

### 快速完成语句

在 IDEA 中，可以使用快捷键 `Ctrl+Shift+Enter` 快速完成声明 `if while` 等语句。

在下面的例子中，我们输入 `while` ，接着我们输入快捷键，我们可以看到 IDEA 自动帮我们完整这个结构，然后只需要输入判断条件即可。

![complete code struct](https://i.postimg.cc/RZcJZgXk/image.gif)

此外，我们还可以用该快捷键完成下面的操作。

![wrap method argument](https://i.postimg.cc/ZR9TCRJW/image.gif)

### Postfix Code

这个模式可以在编写代码时减少向后插入符号跳转。我们可以在变量后面直接跟上 `if `、`for` 等表达式，IDEA 会直接转换成相应的语句。

![postfix-code](https://i.postimg.cc/2S2mGv6q/image.gif)

我们还可以查看在设置中  `Editor | General | Postfix Completion` 查看更多用法。

### Live Template

我们有时候会保存一些代码片段，然后在需要的时候直接粘贴。而 IDEA `Live Template` 就可以帮我们保存这个代码片段，且可以自定义关键字，需要的时候只需要输入关键字，就可以直接输出代码。而且 IDEA 也已经定义很多，我们可以直接上手使用。

![live template](https://i.postimg.cc/ZKLhY36f/image.gif)

如上图，我们可以输入 `psfs`，然后输入回车键或者 `Tab` 键，直接生成 `public static final String`。

输入 `psvm`，快速生成 `main` 方法。

我们可以使用下面的步骤自定义自己的 `Live Template`。

![设置 live-template](https://i.postimg.cc/zv198XvZ/image.png)

### 强大的搜索功能

开发的时候我们会去查看类的源码,有时我们只知道类的名字，却不知道具体包的位置，这个时候IDEA 强大的搜索功能可以帮我们迅速的找到。

我们可以按两下 `shift`，在弹出的窗口输入类名，就可以找到。

![基本搜索功能](https://i.postimg.cc/k50HvXx6/image.gif)

这个功能不仅可以找类，也可以用于找文件等。

还有的时候我们可能只记得类中的某个关键字，那上面的方法就无效。但是没关系，IDEA 还可以帮你用关键字去搜索找到
我们只要输入 `Ctrl+Alt+F` 快捷键。

![关键字搜索](https://i.postimg.cc/wxcrDz3M/image.gif)

## 版本控制功能

在团队开发中，我们就需要使用到相关版本控制工具，比如 SVN、Git 等。IDEA 默认自带强大版本控制工具，可以快速浏览代码变更，仓库提交历史以及合并代码。

我们以 [Dubbo](https://github.com/apache/incubator-dubbo) Git 项目为例。我们可以在 Version Control Log 处图形化查看仓库历史。

![Git log](https://i.postimg.cc/hth3F7sQ/image.png)

协作开发的时候，很容易发生冲突,这个时候如果没有其他很好的工具，解决冲突是一件很麻烦的事，非常容易将代码合丢。

不过使用 IDEA 强大的解决冲突的功能，可以帮我们解决这个问题。

当提交代码时，若存在代码冲突时，IDEA 显示冲突的文件.

![代码冲突](https://i.postimg.cc/FKLWz529/image.png)

点击文件，选择 Merge, 然后会显示窗口，我们可以浏览两边代码，自己灵活选择到底选择本地变更或者服务端的变更。

![合并](https://i.postimg.cc/85gyrXSL/image.png)

这里说个小技巧，我们协作开发时，若有些人使用 `TAB` 作为缩进然后提交代码，而当你使用空格作为缩进，一旦将代码格式化，你提交代码的时候，这个时候冲突就会是个在灾难。如下所示.

![灾难](https://i.postimg.cc/1XJM29NK/image.png)

这样满屏充满干扰的变更的时候，很容易合错代码。

。。。。  
。。。。

我们选择忽略空白行，IDEA 会把这种自动或略空白行，这样我们就可以针对自己变更合并即可。

![减少干扰](https://i.postimg.cc/CLxcDfWr/image.png)

## 重构功能

我们编码的时候有可能会写错单词，写错并不可怕，怕的是你到最后才发现。这个时候你发现许多地方都用到这个，这个时候你在一个个变更就真的很费劲了。

不用怕，IDEA 重构功能就可以帮助到我们。

IDEA 重命名功能可以快速帮修改所有引用这个变量的地方。

![rename](https://i.postimg.cc/ydKPNJmP/image.gif)



## 其他

### 插件

IDEA 安装时就会集成很多官方插件，增加对其他技术，语言的支持。你如果不喜欢，可以根据自己的选择在 `Setting/Plugins` 自由选择启动或禁用。

你还可以在官方的插件平台 <https://plugins.jetbrains.com/>找到一些第三方非常优秀的插件，实现其他扩展功能，如翻译。

### 主题

IDEA 自带两套非常漂亮的主题。一套为亮色的，另一套为暗色的。

![主题](https://i.postimg.cc/tgQdr1Mj/image.png)

个人觉得暗色系列的主题，更加好看，且不刺眼。

如果不喜欢自带的主题，可以自定义，或者下载主题插件，如 `Material Theme UI`。

### 版本更新

IDEA 迭代更新速度较快，基本每半年就会有一个大版本更新，以及时常会有一些小版本更新。每次更新以后都会一些新功能。

## IDEA 一些缺点

上面说了这么多 IDEA 功能，也讲讲一些 IDEA 的缺点。

IDEA 很多强大的功能都是基于其缓存与索引。当打开一个新项目的时候，IDEA 会自动建立索引。这个有时候对大型项目特别不友好，可能会出现卡顿现象。特别对于机械硬盘用户，这种现象会更加明显。

因此强烈建议 IDEA 创建索引的时候不要动项目，等待创建完毕即可。

还有一点就是 IDEA 中没有类似 Eclipse 中的 workspace 的概念，无法做到一个 IDEA 工程打开多个项目。这是刚从 Eclipse 转过来同学困惑的地方。不过等你真正熟悉 IDEA，真的需要 workspace 吗？

## 结束

上面介绍 IDEA 这么多功能，没有在使用的读者们，不妨下载使用看看。刚开始从其他编辑器转过来确实很难，但是一旦你喜欢上 IDEA，你就不会释手了。

IDEA 还有其他很多功能，一篇文章不能全部都说到，各位读者可以自行去探索。博主每次研究 IDEA 的功能时，都能发现一些以前不知道的技巧。


---
> **推荐阅读**：  
>**1、** [**生产系统 SQL 执行异常原因分析**](https://juejin.im/post/5bbca6ede51d450e6d0122bb)  
>**2、** [**在 dubbo 中使用 Threadlocal 的相关问**题](https://juejin.im/post/5b41d1d3e51d45195534556a)  
> **3、** [**从源码学习设计模式之模板方法**](https://juejin.im/post/5c1a309a6fb9a04a0821a0e5)  
>**4、** [**一次慢查询暴露的隐蔽问题**](https://juejin.im/post/5c303f1be51d4551ea7f0037)  

----

**如果觉得好的话，请帮作者点个赞呗~ 谢谢**
**喜欢本文的读者们，欢迎长按关注订阅号程序通事~让我与你分享程序那些事。** 


