title: 分享 IDEA 调试源码的小技巧
date: '2019-11-19 23:57:46'
updated: '2019-11-19 23:57:46'
tags: [IDEA]
permalink: /articles/2019/11/19/1574179066310.html
---
有时候我们调试源码，并不知道代码起点以及代码调用链路，这样可能就无从下手。

举个例子，比如说我想知道 Spring Bean 初始化整个过程，但是我并不熟悉这个调用过程，怎么办？

代码起点不知道，最终调用代码我们肯定清楚。所以我们现在代码最终调用处打上断点。如图所示。

![image.png](https://img.hacpai.com/file/2019/11/image-d48b5fd3.png)

在 IDEA 上开启 DEBUG 模式，程序启动之后，将会暂停这个断点上。我们打开 DEBUG 窗口，打开 `Threads` ，就可以看到代码完整调用链了。

![image.png](https://img.hacpai.com/file/2019/11/image-386222c1.png)

双击其中某个方法，IDEA 就会跳转到这个方法处。




