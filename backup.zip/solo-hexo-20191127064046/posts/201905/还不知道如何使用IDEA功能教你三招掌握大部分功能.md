title: 还不知道如何使用 IDEA 功能？教你三招掌握大部分功能
date: '2019-05-30 01:49:40'
updated: '2019-10-16 12:48:04'
tags: [plugin, tips]
permalink: /articles/2019/05/30/1559152180029.html
---
![](https://img.hacpai.com/bing/20171126.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言

IntelliJ IDEA 是一个非常强大的 IDE，拥有许多功能。在 IDEA 中大部分功能都可以用快捷键去完成，如果掌握了大部分快捷键，可以只使用键盘开发了。

> ps: 最近正在练习快捷键，准备尝试只使用键盘进行开发

也许因为这些繁多的功能，对于新入手 IDEA 的开发人员，快速掌握功能与快捷键并不是很简单。幸运的是 **Jetbrain** 早已考虑到该情况， 在 IDEA 有相关功能，可以快速帮助你上手。

## Tip of the day

首先介绍的是 **Tip of the day** 。这个功能，大家应该都见过。初始安装好 IDEA，打开软件，默认就会弹出下面的窗口。

![Tip of the day](https://i.postimg.cc/6QNFxpmr/1559146186527-8444b0dd-c833-4f41-bb4e-da2661abb31e.png)

默认情况下 **show tips on startup** 选项会勾选，下次打开就会该功能会继续出现。不过我相信很多人，被国内各种弹窗广告迫害，会习惯性的第一时间就会把它取消。

如果你已经取消这个选项，可以在 **HELP | Tip of the day** 打开。

在这个窗口，会显示一个 IDEA 功能，左右切换可以查看其他功能。

[![1559146425081-7d8fc46c-4dbe-4622-bbce-9b52513fac9e.png](https://i.postimg.cc/wTCGDBHC/1559146425081-7d8fc46c-4dbe-4622-bbce-9b52513fac9e.png)](https://postimg.cc/BXCp04jp)

[![1559146470415-01f00581-4e24-480c-b5fa-27102e4a6260.png](https://i.postimg.cc/Pqr95RdJ/1559146470415-01f00581-4e24-480c-b5fa-27102e4a6260.png)](https://postimg.cc/VJpD74rP)


## productivity guide

第二个介绍  **productivity guide**。

上面我们提到 IDEA 中存在很多功能以及快捷键，但你知道你经常使用是那几个功能以及使用频率如何？

在 IDEA 中打开 **productivity guide**，在这里你不仅可以看到经常使用的功能，还会展示你从未使用的功能。

我们可以在 **Help | Productivity Guide** 打开。

![Productivity Guide](https://i.postimg.cc/GhF5JC29/1559146867467-ddd72b8e-1b83-4d7e-b7fa-cc8f8d7655b9.png)

这个窗口可以看到 IDEA 统计相关功能使用情况。点击未在使用的功能，在下面的面板，会给出相关提示。

![使用技巧](https://i.postimg.cc/pdTcH5Bn/1559149116615-cfb17e0f-a8c4-4a81-a4f7-397546df2abf.png)

如果旁边的小伙伴也在使用 IDEA，不妨互相比较一下相关数据，也许能发现一些有趣的现象。

## 插件 IDE Features Trainer

介绍 IDEA 自带的两个功能，下面介绍一款插件。这款插件由 IDEA 官方开发，5星认证好评。

在 **setting|plugins** 输入 **IDE Features Trainer**，就能找到这款插件。

![IDE Features Trainer](https://i.postimg.cc/D0qBgr7R/1559149216148-1125dfe1-f0f5-488e-a542-852f59df0085.png)

安装之后，打开 IDEA，可以在首页看到  **Learn Intellij IDEA** 选项。

![首页](https://cdn.nlark.com/yuque/0/2019/png/254022/1559149277956-1ae9ad53-8713-46c3-a964-72e19cc36b25.png)

点击选项会进入一个内置工程。

![内置功能](https://i.postimg.cc/DwfBr4HY/1559149344747-9f3d2bba-cf66-410c-9b8b-de6be61c252c.png)

> 哈哈，目前只完成两个，正在跟着学习相关快捷键。

这个插件主要教你学会五类相关功能，分别为：

**Editor Basics**：相关的编辑技巧。

**Code Completion**：代码提示快捷键，一些快捷完成代码的及技巧。

**Refactoring**：代码重构的技巧。

**Code Assistance**：代码只能提示功能，可以快速格式化以及查看方法参数等。

**Navigation**: 导航功能，可以快速搜索文件，类，方法名。这个真的不得不吹一下，IDEA 搜索功能快速且方便。

相关子功能示例：

![示例](https://i.postimg.cc/Wz6wrsnv/1559149885867-c20c8abb-ce04-49ab-99ca-e7f53ca27d7f.png)

掌握这五类技巧，可以说已经掌握 IDEA 的核心功能。


## 总结

IDEA 上手简单，但是想熟练掌握，却还是需要大量的练习。上面三个技巧只能帮助你去了解相关功能，能否掌握还得靠自己去练习。

