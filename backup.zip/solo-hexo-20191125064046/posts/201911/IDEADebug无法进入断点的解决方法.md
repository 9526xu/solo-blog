title: IDEA Debug 无法进入断点的解决方法
date: '2019-11-16 11:27:26'
updated: '2019-11-16 11:29:48'
tags: [IDEA]
permalink: /idea_breakpoint_not_use
---
![](https://img.hacpai.com/bing/20190904.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

某个多模块项目中使用多个版本的 Spring，如 Spring 4，Spring 5，在使用 IDEA Debug 过程中发现，Spring 部分 jar 如 spring-core 中的上面断点，IDEA 可以成功进入。但是有部分如 spring-context IDEA 始终无法进入断点。

当 IDEA 进入 spring-core 断点时，打开 spring-context  任意源码，可以发现 IDEA 提示 **source code does not match bytecode**。

![source code does not match bytecode](https://img.hacpai.com/file/2019/11/image-ede480ec.png)

看到这个提示，大概知道了问题。

主要原因为应用中使用 Spring4 ，调试过程中却选择 Spring5 源码，由于两个版本肯定存在一些改动，导致 Spring5 的源码对应不上 Spring4 字节码， IDEA Debug 无法进入相关断点。

## 解决方法

知道问题的原因，需要找到解决办法。~~刚开始以为 IDEA 缓存问题，于是 **Build-Rebuild Project** 重新构建工程，重新调试，并没有什么鸟用~~。

没办法，只能在网上搜索相关解决办法，于是乎在万能的   [**stackoverflow**](https://stackoverflow.com/questions/39990752/source-code-does-not-match-the-bytecode-when-debugging-on-a-device) 找到解决办法。

**解决方案：**

如果应用中存在多个版本 jar 包时，IDEA 调试过程将会看到如下提示。

![image.png](https://img.hacpai.com/file/2019/11/image-e7acbb68.png)

在这里我们可以选择相应的版本进行调试。

如果很不幸，就像我一样，没有显示这个提示，很可能某次调试过程禁用这个功能。不过也没关系，我们可以重新在设置 **Preferences/Debuggers** 重新打开该选项。如图所示：

![null](https://i.stack.imgur.com/5zCf8.png)

